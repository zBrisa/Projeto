<?php
$terms_url  = get_theme_mod( 'metodo_descoberta_terms_url', '' );
$privacy_url = get_theme_mod( 'metodo_descoberta_privacy_url', '' );
$contact_url = get_theme_mod( 'metodo_descoberta_contact_url', '' );
?>
<footer class="site-footer">
	<div class="container footer-inner">
		<div class="footer-brand"><?php echo metodo_descoberta_icon( 'lock' ); ?><span>Método Descoberta</span></div>
		<p>© <?php echo esc_html( gmdate( 'Y' ) ); ?> Método Descoberta. Todos os direitos reservados.</p>
		<nav class="footer-nav" aria-label="Links institucionais">
			<a href="<?php echo esc_url( $terms_url ? $terms_url : '#' ); ?>">Termos de Uso</a>
			<a href="<?php echo esc_url( $privacy_url ? $privacy_url : '#' ); ?>">Política de Privacidade</a>
			<a href="<?php echo esc_url( $contact_url ? $contact_url : '#' ); ?>">Contato</a>
		</nav>
		<p class="ethical-note">O Método Descoberta é um guia educativo de análise comportamental, observação discreta e rastreamento de pegadas digitais de forma ética e legal. Não incentiva, promove ou sugere invasão de privacidade, hacking ou qualquer prática ilegal.</p>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
