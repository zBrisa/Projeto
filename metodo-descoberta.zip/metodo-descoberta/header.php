<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Guia de análise comportamental e observação discreta para descobrir a verdade sobre o seu relacionamento, proteger seu emocional e ter clareza.">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
	<div class="container header-inner">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Método Descoberta — início">
			<span class="icon-shell"><?php echo metodo_descoberta_icon( 'eye' ); ?></span>
			<span>Método Descoberta</span>
		</a>
		<div class="header-security"><?php echo metodo_descoberta_icon( 'lock' ); ?><span>Acesso 100% sigiloso</span></div>
	</div>
</header>
