<?php
/**
 * Funções do tema Método Descoberta.
 *
 * @package MetodoDescoberta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function metodo_descoberta_setup() {
	load_theme_textdomain( 'metodo-descoberta', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
}
add_action( 'after_setup_theme', 'metodo_descoberta_setup' );

function metodo_descoberta_assets() {
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'metodo-descoberta-fonts', 'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300;9..144,600&family=Manrope:wght@400;500;600;700;800&display=swap', array(), null );
	wp_enqueue_style( 'metodo-descoberta-style', get_stylesheet_uri(), array( 'metodo-descoberta-fonts' ), $version );
	wp_enqueue_script( 'metodo-descoberta-script', get_template_directory_uri() . '/assets/js/theme.js', array(), $version, true );
}
add_action( 'wp_enqueue_scripts', 'metodo_descoberta_assets' );

function metodo_descoberta_customize_register( $wp_customize ) {
	$wp_customize->add_section( 'metodo_descoberta_offer', array(
		'title'       => __( 'Método Descoberta — Oferta', 'metodo-descoberta' ),
		'description' => __( 'Defina os dados comerciais sem editar o código.', 'metodo-descoberta' ),
		'priority'    => 30,
	) );

	$settings = array(
		'metodo_descoberta_price' => array( 'Preço', 'R$ XX,XX', 'sanitize_text_field' ),
		'metodo_descoberta_checkout_url' => array( 'Link do checkout', '', 'esc_url_raw' ),
		'metodo_descoberta_terms_url' => array( 'Link dos Termos de Uso', '', 'esc_url_raw' ),
		'metodo_descoberta_privacy_url' => array( 'Link da Política de Privacidade', '', 'esc_url_raw' ),
		'metodo_descoberta_contact_url' => array( 'Link de Contato', '', 'esc_url_raw' ),
	);

	foreach ( $settings as $id => $config ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $config[1],
			'sanitize_callback' => $config[2],
		) );
		$wp_customize->add_control( $id, array(
			'label'   => __( $config[0], 'metodo-descoberta' ),
			'section' => 'metodo_descoberta_offer',
			'type'    => 'text',
		) );
	}
}
add_action( 'customize_register', 'metodo_descoberta_customize_register' );

function metodo_descoberta_icon( $name, $class = '' ) {
	$paths = array(
		'eye' => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
		'lock' => '<rect width="14" height="11" x="5" y="11" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
		'check' => '<path d="m5 12 4 4L19 6"/>',
		'shield' => '<path d="M20 13c0 5-3.5 7.5-8 9-4.5-1.5-8-4-8-9V5l8-3 8 3v8Z"/><path d="m9 12 2 2 4-4"/>',
		'heart' => '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"/>',
		'phone' => '<rect width="14" height="20" x="5" y="2" rx="2"/><path d="M12 18h.01"/>',
		'brain' => '<path d="M9.5 4A2.5 2.5 0 0 0 7 6.5v.4A3 3 0 0 0 5 12a3 3 0 0 0 2 5.1v.4A2.5 2.5 0 0 0 9.5 20H12V4H9.5ZM14.5 4A2.5 2.5 0 0 1 17 6.5v.4a3 3 0 0 1 2 5.1 3 3 0 0 1-2 5.1v.4a2.5 2.5 0 0 1-2.5 2.5H12V4h2.5Z"/>',
		'compass' => '<circle cx="12" cy="12" r="10"/><path d="m16 8-2 6-6 2 2-6 6-2Z"/>',
		'list' => '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
		'search' => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
		'sparkle' => '<path d="m12 3-1.5 4.5L6 9l4.5 1.5L12 15l1.5-4.5L18 9l-4.5-1.5L12 3ZM5 16l-.7 2.3L2 19l2.3.7L5 22l.7-2.3L8 19l-2.3-.7L5 16Z"/>',
		'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
		'star' => '<path d="m12 2 3.1 6.3 6.9 1-5 4.8 1.2 6.9-6.2-3.3L5.8 21 7 14.1l-5-4.8 6.9-1L12 2Z"/>',
		'quote' => '<path d="M3 21c3 0 7-1 7-8V5c0-1.2-.8-2-2-2H4c-1.2 0-2 .8-2 2v6c0 1.2.8 2 2 2h2c0 4-1 5-3 6v2ZM14 21c3 0 7-1 7-8V5c0-1.2-.8-2-2-2h-4c-1.2 0-2 .8-2 2v6c0 1.2.8 2 2 2h2c0 4-1 5-3 6v2Z"/>',
		'chevron-left' => '<path d="m15 18-6-6 6-6"/>',
		'chevron-right' => '<path d="m9 18 6-6-6-6"/>',
		'chevron-down' => '<path d="m6 9 6 6 6-6"/>',
	);
	$path = isset( $paths[ $name ] ) ? $paths[ $name ] : $paths['check'];
	return '<svg class="icon ' . esc_attr( $class ) . '" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' . $path . '</svg>';
}
