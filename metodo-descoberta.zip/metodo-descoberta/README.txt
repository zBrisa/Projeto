MÉTODO DESCOBERTA — TEMA WORDPRESS 1.0.0
========================================

INSTALAÇÃO PELO PAINEL
1. Use o arquivo metodo-descoberta.zip.
2. No WordPress, abra Aparência > Temas > Adicionar novo > Enviar tema.
3. Selecione o ZIP, instale e ative.
4. Abra Aparência > Personalizar > Método Descoberta — Oferta.
5. Informe o preço, o link do checkout e os links institucionais.
6. Salve e publique.

INSTALAÇÃO MANUAL
1. Copie a pasta metodo-descoberta para wp-content/themes/.
2. Ative o tema em Aparência > Temas.

CONFIGURAÇÕES
- Preço padrão: R$ XX,XX (placeholder intencional).
- O botão de compra fica visualmente desativado até um link de checkout ser informado.
- Termos, Privacidade e Contato usam # até receberem URLs reais.
- O contador começa em 15:00 a cada carregamento, sem alegação de unidades limitadas.

ARQUIVOS PRINCIPAIS
- front-page.php: conteúdo completo da página de vendas.
- style.css: identificação e aparência do tema.
- functions.php: recursos, configurações e ícones.
- header.php / footer.php: topo e rodapé.
- assets/js/theme.js: contador, FAQ e carrossel.
- assets/images/: imagens locais usadas na página.

OBSERVAÇÕES
- Não exige plugins, React, Tailwind ou Lovable.
- Fontes Fraunces e Manrope são carregadas do Google Fonts. Se sua política de privacidade exigir hospedagem local, baixe e hospede essas fontes no próprio tema.
- O conteúdo mantém o aviso de uso ético e legal; não promove hacking ou invasão de privacidade.
