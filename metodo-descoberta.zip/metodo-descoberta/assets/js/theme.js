(function () {
  'use strict';

  document.querySelectorAll('[data-countdown]').forEach(function (timer) {
    var seconds = Number(timer.getAttribute('data-countdown')) || 900;
    var output = timer.querySelector('strong');
    function render() {
      var minutes = String(Math.floor(seconds / 60)).padStart(2, '0');
      var remaining = String(seconds % 60).padStart(2, '0');
      output.textContent = minutes + ':' + remaining;
    }
    render();
    window.setInterval(function () {
      seconds = Math.max(0, seconds - 1);
      render();
    }, 1000);
  });

  document.querySelectorAll('.faq-item button').forEach(function (button) {
    button.addEventListener('click', function () {
      var item = button.closest('.faq-item');
      var panel = document.getElementById(button.getAttribute('aria-controls'));
      var willOpen = button.getAttribute('aria-expanded') !== 'true';
      button.setAttribute('aria-expanded', String(willOpen));
      item.classList.toggle('is-open', willOpen);
      panel.hidden = !willOpen;
    });
  });

  document.querySelectorAll('[data-carousel]').forEach(function (carousel) {
    var track = carousel.querySelector('.carousel-track');
    var slides = Array.from(carousel.querySelectorAll('.carousel-slide'));
    var dots = Array.from(carousel.parentElement.querySelectorAll('.carousel-dots button'));
    var current = 0;
    function goTo(index) {
      current = (index + slides.length) % slides.length;
      track.style.transform = 'translateX(-' + current * 100 + '%)';
      slides.forEach(function (slide, i) { slide.setAttribute('aria-hidden', String(i !== current)); });
      dots.forEach(function (dot, i) { dot.setAttribute('aria-current', String(i === current)); });
    }
    carousel.querySelector('.prev').addEventListener('click', function () { goTo(current - 1); });
    carousel.querySelector('.next').addEventListener('click', function () { goTo(current + 1); });
    dots.forEach(function (dot) { dot.addEventListener('click', function () { goTo(Number(dot.dataset.slide)); }); });
    carousel.addEventListener('keydown', function (event) {
      if (event.key === 'ArrowLeft') goTo(current - 1);
      if (event.key === 'ArrowRight') goTo(current + 1);
    });
  });
})();
