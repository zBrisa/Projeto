<?php
/** Página de vendas principal. */
get_header();
$theme_uri = get_template_directory_uri();
$price = get_theme_mod( 'metodo_descoberta_price', 'R$ XX,XX' );
$checkout = get_theme_mod( 'metodo_descoberta_checkout_url', '' );
$receive = array(
	array( 'list', 'Passo a passo de análise', 'Analise comportamentos e mudanças de rotina com um método claro e organizado.' ),
	array( 'eye', 'Observação discreta', 'Técnicas para observar sem levantar suspeitas, no seu ritmo e no seu tempo.' ),
	array( 'phone', 'Pegadas digitais', 'Guia de rastreamento de pegadas digitais e redes sociais, de forma ética.' ),
	array( 'heart', 'Proteção emocional', 'Foco total na sua saúde mental durante todo o processo de investigação.' ),
	array( 'brain', 'Fim da ansiedade', 'Clareza mental para acabar com o desgaste de viver na dúvida.' ),
	array( 'compass', 'Como agir', 'Preparação para saber como agir e tomar as melhores decisões com a verdade em mãos.' ),
	array( 'lock', 'Discrição total', 'Conduza toda a situação em sigilo, sem se expor nem alertar ninguém.' ),
);
$why = array(
	array( 'lock', 'Discrição Absoluta', 'Aprenda a observar e coletar informações sem que a outra pessoa perceba.' ),
	array( 'check', 'Fim da Ansiedade', 'Pare de viver em cima de “achismos” e tenha fatos e sinais claros.' ),
	array( 'shield', 'Proteção Emocional', 'O método ensina como se preparar psicologicamente para lidar com a verdade.' ),
	array( 'search', 'Análise Inteligente', 'Vá além do ciúmes: aprenda a ler padrões de comportamento e linguagem corporal.' ),
	array( 'phone', 'Segurança Digital', 'Saiba o que observar no uso de celulares e redes sociais de forma ética e discreta.' ),
	array( 'sparkle', 'Empoderamento', 'Retome o controle da sua vida e das suas decisões com base na verdade.' ),
);
$bonuses = array(
	array( '01', 'search', 'Guia de Rastreamento Digital Discreto', 'Um manual prático sobre como observar padrões de uso de celular, redes sociais e aplicativos de mensagens — sem invadir a privacidade de forma ilegal e sem ser descoberto.' ),
	array( '02', 'eye', 'Manual de Linguagem Corporal e Microexpressões', 'Material com orientações para identificar mentiras, desconforto e mudanças sutis no comportamento e na comunicação do seu parceiro(a).' ),
	array( '03', 'heart', 'Guia de Proteção Emocional e Próximo Passo', 'Um guia de acolhimento para lidar com a ansiedade da investigação e saber como planejar sua vida e suas decisões depois de ter a verdade em mãos.' ),
);
$included = array( 'Método Descoberta (acesso completo)', 'Bônus 1: Guia de Rastreamento Digital Discreto', 'Bônus 2: Manual de Linguagem Corporal e Microexpressões', 'Bônus 3: Guia de Proteção Emocional e Próximo Passo' );
$slides = array(
	array( 'slide-1.jpg', 'Capa do guia Método Descoberta em azul marinho com detalhes dourados', 'O guia completo, com visual sóbrio e profissional' ),
	array( 'slide-2.jpg', 'Checklist de sinais comportamentais em interface escura e elegante', 'Checklists de sinais comportamentais para acompanhar com clareza' ),
	array( 'slide-3.jpg', 'Painel de análise de pegadas digitais com gráficos em tons escuros e dourados', 'Análise discreta de pegadas digitais e redes sociais' ),
	array( 'slide-4.jpg', 'Manual aberto com ilustrações em linha dourada sobre linguagem corporal e microexpressões', 'Manual de linguagem corporal e microexpressões' ),
	array( 'slide-5.jpg', 'Interface calma de proteção emocional com plano passo a passo em tons escuros', 'Organização mental, proteção emocional e próximo passo' ),
);
$testimonials = array(
	array( 'C', 'Carla', 'Eu vivia ansiosa, criando cenários na minha cabeça e me sentindo louca. O método me deu um passo a passo claro e discreto. Finalmente tive a certeza que precisava para tomar uma decisão e proteger meu coração.' ),
	array( 'F', 'Fernanda', 'O que mais me ajudou foi o guia de rastreamento digital. Consegui entender o que estava acontecendo no celular dele sem levantar nenhuma suspeita e sem me expor. O material é muito inteligente.' ),
	array( 'B', 'Beatriz', 'Achei que ia enlouquecer de tanta dúvida. O Método Descoberta me trouxe paz de espírito, pois agora sei exatamente como agir, o que observar e como me proteger emocionalmente.' ),
);
$faqs = array(
	array( 'Como vou receber o material?', 'Após a confirmação da compra, você receberá as instruções necessárias para acessar o material digital de forma 100% sigilosa no seu e-mail e dispositivo.' ),
	array( 'O método ensina a hackear celulares ou invadir privacidade?', 'Não. O Método Descoberta é focado em análise comportamental, observação discreta e rastreamento de pegadas digitais de forma ética e legal, sem a necessidade de cometer crimes cibernéticos.' ),
	array( 'Como faço para investigar sem que a outra pessoa perceba?', 'O material possui um módulo inteiro dedicado à discrição, ensinando como mudar sua postura, o que observar e como agir naturalmente para não levantar suspeitas.' ),
	array( 'E se eu aplicar o método e descobrir que não há infidelidade?', 'Você terá ganhado algo inestimável: paz de espírito. O método também ajuda a identificar outros padrões de comportamento, melhorando a comunicação e a confiança no relacionamento.' ),
	array( 'E se eu comprar e não gostar?', 'Você conta com uma garantia incondicional de 7 dias. Dentro desse período, poderá solicitar o reembolso conforme as condições da garantia, sem burocracia.' ),
);
?>
<main id="conteudo">
<section class="hero">
	<div class="hero-aura" aria-hidden="true"></div>
	<div class="container hero-grid">
		<div class="hero-copy">
			<div class="eyebrow-badge"><span class="pulse"></span><?php echo metodo_descoberta_icon( 'eye' ); ?>Análise comportamental · Observação discreta · Sigilo total</div>
			<h1><span>Método</span><strong>Descoberta</strong></h1>
			<p>Tenha clareza, proteja seu emocional e descubra a verdade sobre o seu relacionamento através de técnicas de análise comportamental e observação discreta.</p>
			<a class="button button-gold" href="#oferta">Quero descobrir a verdade agora</a>
			<small>Acesso 100% sigiloso · Garantia incondicional de 7 dias</small>
		</div>
		<div class="hero-media"><img src="<?php echo esc_url( $theme_uri . '/assets/images/hero.jpg' ); ?>" width="864" height="1152" alt="Pessoa analisando calmamente a tela do smartphone em um ambiente sereno, com discrição e clareza"></div>
	</div>
</section>

<section class="section section-alt">
	<div class="container">
		<div class="section-heading"><p>O que você vai receber</p><h2>Tudo o que você precisa para sair da dúvida e ter o controle da situação</h2><div>Com o Método Descoberta, você terá acesso a um material completo: um passo a passo pensado para investigar sinais de infidelidade de forma inteligente, sem levantar suspeitas e protegendo a sua saúde mental.</div></div>
		<div class="grid cards-3"><?php foreach ( $receive as $item ) : ?><article class="card hover-card"><span class="feature-icon"><?php echo metodo_descoberta_icon( $item[0] ); ?></span><h3><?php echo esc_html( $item[1] ); ?></h3><p><?php echo esc_html( $item[2] ); ?></p></article><?php endforeach; ?></div>
	</div>
</section>

<section class="section">
	<div class="container">
		<div class="section-heading"><p>Por que escolher nosso material</p><h2>Por que o Método Descoberta é a escolha certa para o seu momento?</h2></div>
		<div class="grid cards-3 why-grid"><?php foreach ( $why as $item ) : ?><article class="card hover-card horizontal-card"><span class="feature-icon round"><?php echo metodo_descoberta_icon( $item[0] ); ?></span><div><h3><?php echo esc_html( $item[1] ); ?></h3><p><?php echo esc_html( $item[2] ); ?></p></div></article><?php endforeach; ?></div>
		<p class="ethical-inline"><?php echo metodo_descoberta_icon( 'eye' ); ?> Tudo isso, observando, analisando e agindo com ética — sem invadir a privacidade de ninguém.</p>
	</div>
</section>

<section class="section section-alt">
	<div class="container">
		<div class="section-heading"><p>Bônus inclusos</p><h2>E ainda existem 3 bônus especiais para você!</h2><div>Além do método completo, estes três bônus chegam junto na sua compra para dar clareza, discrição e proteção emocional em cada etapa.</div></div>
		<div class="grid cards-3 bonus-grid"><?php foreach ( $bonuses as $bonus ) : ?><article class="card hover-card bonus-card"><span class="bonus-number" aria-hidden="true"><?php echo esc_html( $bonus[0] ); ?></span><span class="bonus-label">Bônus <?php echo esc_html( (string) intval( $bonus[0] ) ); ?></span><span class="feature-icon"><?php echo metodo_descoberta_icon( $bonus[1] ); ?></span><h3><?php echo esc_html( $bonus[2] ); ?></h3><p><?php echo esc_html( $bonus[3] ); ?></p><strong>Incluído gratuitamente na sua compra</strong></article><?php endforeach; ?></div>
	</div>
</section>

<section id="oferta" class="section offer-section">
	<div class="container narrow">
		<div class="offer-card">
			<p class="kicker">Oferta especial</p><h2>Tenha acesso agora ao Método Descoberta</h2><p>Um único acesso com o método completo e os três bônus inclusos:</p>
			<ul class="included"><?php foreach ( $included as $item ) : ?><li><span><?php echo metodo_descoberta_icon( 'check' ); ?></span><?php echo esc_html( $item ); ?></li><?php endforeach; ?></ul>
			<div class="price"><small>Valor da oferta</small><strong><?php echo esc_html( $price ); ?></strong></div>
			<?php if ( $checkout ) : ?><a class="button button-gold" href="<?php echo esc_url( $checkout ); ?>" rel="noopener">Quero acessar o método agora</a><?php else : ?><span class="button button-gold button-disabled" title="Configure o link do checkout no Personalizador">Quero acessar o método agora</span><?php endif; ?>
			<div class="countdown" data-countdown="900"><span><?php echo metodo_descoberta_icon( 'clock' ); ?> Essa condição especial está disponível por tempo limitado.</span><strong aria-live="polite">15:00</strong><small>minutos : segundos</small></div>
			<p class="secure"><?php echo metodo_descoberta_icon( 'shield' ); ?> Compra 100% segura e privada · Garantia incondicional de 7 dias</p>
		</div>
	</div>
</section>

<section class="section section-alt">
	<div class="container showcase-container">
		<div class="section-heading"><p>Por dentro do método</p><h2>Dê uma olhada em como o Método Descoberta vai te guiar</h2></div>
		<div class="carousel" data-carousel tabindex="0" aria-label="Imagens do Método Descoberta">
			<div class="carousel-track"><?php foreach ( $slides as $index => $slide ) : ?><figure class="carousel-slide" aria-hidden="<?php echo 0 === $index ? 'false' : 'true'; ?>"><img src="<?php echo esc_url( $theme_uri . '/assets/images/' . $slide[0] ); ?>" width="1280" height="1024" loading="lazy" alt="<?php echo esc_attr( $slide[1] ); ?>"><figcaption><?php echo esc_html( $slide[2] ); ?></figcaption></figure><?php endforeach; ?></div>
			<button class="carousel-arrow prev" type="button" aria-label="Slide anterior"><?php echo metodo_descoberta_icon( 'chevron-left' ); ?></button><button class="carousel-arrow next" type="button" aria-label="Próximo slide"><?php echo metodo_descoberta_icon( 'chevron-right' ); ?></button>
		</div>
		<div class="carousel-dots" aria-label="Escolher slide"><?php foreach ( $slides as $index => $slide ) : ?><button type="button" aria-label="Ir para o slide <?php echo esc_attr( (string) ( $index + 1 ) ); ?>" aria-current="<?php echo 0 === $index ? 'true' : 'false'; ?>" data-slide="<?php echo esc_attr( (string) $index ); ?>"></button><?php endforeach; ?></div>
	</div>
</section>

<section class="section">
	<div class="container">
		<div class="section-heading"><p>Depoimentos de exemplo</p><h2>Quem buscou clareza, recuperou o controle da própria vida</h2><div>Relatos ilustrativos de como o método ajuda a sair da dúvida e a agir com segurança.</div></div>
		<div class="grid cards-3 testimonial-grid"><?php foreach ( $testimonials as $item ) : ?><figure class="card hover-card testimonial"><div class="stars"><?php for ( $i = 0; $i < 5; $i++ ) { echo metodo_descoberta_icon( 'star' ); } ?></div><blockquote>“<?php echo esc_html( $item[2] ); ?>”</blockquote><figcaption><span><?php echo esc_html( $item[0] ); ?></span>— <?php echo esc_html( $item[1] ); ?>, cliente</figcaption></figure><?php endforeach; ?></div>
		<p class="example-note">Depoimentos apresentados como exemplos ilustrativos.</p>
	</div>
</section>

<section class="section section-alt"><div class="container guarantee-wrap"><div class="guarantee-card"><div class="seal"><strong>7</strong><span>DIAS</span></div><p class="kicker emerald">Garantia incondicional de 7 dias</p><h2>Você tem 7 dias para experimentar com total sigilo</h2><p>Você pode adquirir o método e estudar as técnicas com tranquilidade e discrição. Se dentro de 7 dias você entender que o conteúdo não é para você, poderá solicitar o reembolso dentro das condições da garantia. Seu acesso é 100% seguro e privado.</p><ul class="guarantee-list"><li><?php echo metodo_descoberta_icon( 'shield' ); ?> Acesso 100% seguro e privado</li><li><?php echo metodo_descoberta_icon( 'shield' ); ?> Estudo no seu ritmo, com total discrição</li><li><?php echo metodo_descoberta_icon( 'shield' ); ?> Reembolso dentro das condições da garantia</li></ul></div></div></section>

<section class="section faq-section"><div class="container faq-wrap"><div class="section-heading"><p>Dúvidas frequentes</p><h2>Perguntas Frequentes</h2></div><div class="faq-list"><?php foreach ( $faqs as $index => $faq ) : $open = 0 === $index; ?><article class="faq-item<?php echo $open ? ' is-open' : ''; ?>"><h3><button type="button" aria-expanded="<?php echo $open ? 'true' : 'false'; ?>" aria-controls="faq-panel-<?php echo esc_attr( (string) $index ); ?>"><span><?php echo esc_html( $faq[0] ); ?></span><?php echo metodo_descoberta_icon( 'chevron-down' ); ?></button></h3><div class="faq-panel" id="faq-panel-<?php echo esc_attr( (string) $index ); ?>"<?php echo $open ? '' : ' hidden'; ?>><p><?php echo esc_html( $faq[1] ); ?></p></div></article><?php endforeach; ?></div></div></section>
</main>
<?php get_footer(); ?>
